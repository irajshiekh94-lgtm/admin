import './globals.css'

export const metadata = {
  title: 'AL Khidmat - Recruitment Management',
  description: 'Admin dashboard for recruitment management',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
