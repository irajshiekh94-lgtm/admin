'use client'

import { createContext, useContext, useState, useEffect } from 'react'

// Mock initial candidate data
const initialCandidatesData = [
  { id: 1, name: 'Aisha Khan', position: 'Project Manager', date: '2023-08-15', status: 'applied', email: 'aisha.khan@email.com', phone: '+1-555-987-6543', address: '456 Oak Avenue, Anytown, USA' },
  { id: 2, name: 'Omar Hassan', position: 'Software Engineer', date: '2023-08-16', status: 'interviewing', email: 'omar.hassan@email.com', phone: '+1-555-987-6544', address: '123 Main St, Anytown, USA' },
  { id: 3, name: 'Fatima Ali', position: 'Data Analyst', date: '2023-08-17', status: 'applied', email: 'fatima.ali@email.com', phone: '+1-555-987-6545', address: '789 Pine St, Anytown, USA' },
  { id: 4, name: 'Zain Malik', position: 'Marketing Specialist', date: '2023-08-18', status: 'interviewing', email: 'zain.malik@email.com', phone: '+1-555-987-6546', address: '321 Elm St, Anytown, USA' },
  { id: 5, name: 'Sara Ahmed', position: 'UX Designer', date: '2023-08-19', status: 'applied', email: 'sara.ahmed@email.com', phone: '+1-555-987-6547', address: '654 Cedar Ave, Anytown, USA' },
  { id: 6, name: 'Ali Raza', position: 'Financial Analyst', date: '2023-08-20', status: 'applied', email: 'ali.raza@email.com', phone: '+1-555-987-6548', address: '987 Birch Ln, Anytown, USA' },
  { id: 7, name: 'Hina Khan', position: 'HR Manager', date: '2023-08-21', status: 'applied', email: 'hina.khan@email.com', phone: '+1-555-987-6549', address: '147 Maple Dr, Anytown, USA' },
  { id: 8, name: 'Bilal Qureshi', position: 'Operations Manager', date: '2023-08-22', status: 'applied', email: 'bilal.qureshi@email.com', phone: '+1-555-987-6550', address: '258 Oak St, Anytown, USA' },
  { id: 9, name: 'Nadia Siddiqui', position: 'Sales Executive', date: '2023-08-23', status: 'applied', email: 'nadia.siddiqui@email.com', phone: '+1-555-987-6551', address: '369 Willow Way, Anytown, USA' },
  { id: 10, name: 'Kamran Shah', position: 'Customer Support', date: '2023-08-24', status: 'applied', email: 'kamran.shah@email.com', phone: '+1-555-987-6552', address: '741 Spruce St, Anytown, USA' },
]

const ApplicationContext = createContext()

export function ApplicationProvider({ children }) {
  const [candidates, setCandidates] = useState(initialCandidatesData)
  const [notes, setNotes] = useState({})

  // Load data from localStorage on mount
  useEffect(() => {
    const savedCandidates = localStorage.getItem('candidates')
    const savedNotes = localStorage.getItem('candidateNotes')
    
    if (savedCandidates) {
      setCandidates(JSON.parse(savedCandidates))
    }
    
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes))
    }
  }, [])

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem('candidates', JSON.stringify(candidates))
  }, [candidates])

  useEffect(() => {
    localStorage.setItem('candidateNotes', JSON.stringify(notes))
  }, [notes])

  const updateCandidateStatus = (candidateId, newStatus) => {
    setCandidates(prev => 
      prev.map(candidate => 
        candidate.id === parseInt(candidateId) 
          ? { ...candidate, status: newStatus }
          : candidate
      )
    )
  }

  const updateCandidateNote = (candidateId, note) => {
    setNotes(prev => ({
      ...prev,
      [candidateId]: note
    }))
  }

  const getCandidateById = (id) => {
    return candidates.find(candidate => candidate.id === parseInt(id))
  }

  const getCandidateNote = (candidateId) => {
    return notes[candidateId] || ''
  }

  const searchCandidates = (searchTerm) => {
    if (!searchTerm.trim()) return []
    
    return candidates.filter(candidate => 
      candidate.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
  }

  const value = {
    candidates,
    updateCandidateStatus,
    updateCandidateNote,
    getCandidateById,
    getCandidateNote,
    searchCandidates
  }

  return (
    <ApplicationContext.Provider value={value}>
      {children}
    </ApplicationContext.Provider>
  )
}

export function useApplicationContext() {
  const context = useContext(ApplicationContext)
  if (!context) {
    throw new Error('useApplicationContext must be used within an ApplicationProvider')
  }
  return context
}
