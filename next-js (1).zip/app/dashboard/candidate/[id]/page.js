'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft, Download, Save } from 'lucide-react'
import { useApplicationContext } from '../../context/ApplicationContext'

export default function CandidateDetails({ params }) {
  const { getCandidateById, updateCandidateStatus, getCandidateNote, updateCandidateNote } = useApplicationContext()
  const candidate = getCandidateById(params.id)

  const [applicationStatus, setApplicationStatus] = useState('')
  const [interviewDateTime, setInterviewDateTime] = useState('')
  const [notes, setNotes] = useState('')

  useEffect(() => {
    if (candidate) {
      setApplicationStatus(candidate.status || 'applied')
      setNotes(getCandidateNote(params.id))
    }
  }, [candidate, params.id, getCandidateNote])

  if (!candidate) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold text-gray-900">Candidate not found</h2>
        <Link href="/dashboard" className="text-blue-600 hover:text-blue-800 mt-2 inline-block">
          Back to Dashboard
        </Link>
      </div>
    )
  }

  const handleStatusChange = (newStatus) => {
    setApplicationStatus(newStatus)
    updateCandidateStatus(params.id, newStatus)
  }

  const handleSaveNote = () => {
    updateCandidateNote(params.id, notes)
    alert('Note saved successfully!')
  }

  const getStatusBadge = (status) => {
    const baseClasses = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium'
    
    switch (status.toLowerCase()) {
      case 'applied':
        return `${baseClasses} bg-gray-100 text-gray-800`
      case 'interviewing':
        return `${baseClasses} bg-blue-100 text-blue-800`
      case 'rejected':
        return `${baseClasses} bg-red-100 text-red-800`
      default:
        return `${baseClasses} bg-gray-100 text-gray-800`
    }
  }

  return (
    <div className="space-y-6">
      {/* Header with back button */}
      <div className="flex items-center space-x-4">
        <Link
          href="/dashboard"
          className="inline-flex items-center text-gray-500 hover:text-gray-700"
        >
          <ArrowLeft className="h-5 w-5 mr-1" />
          Back
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Personal Info & Application History */}
        <div className="lg:col-span-2 space-y-6">
          {/* Personal Information */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Candidate Details</h2>
            
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Personal Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-500">Full Name</label>
                  <p className="font-medium">{candidate.name}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Email</label>
                  <p className="font-medium">{candidate.email}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Phone Number</label>
                  <p className="font-medium">{candidate.phone}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Address</label>
                  <p className="font-medium">{candidate.address}</p>
                </div>
              </div>
            </div>

            {/* Application History */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">Application History</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-2 text-sm font-medium text-gray-500">Date</th>
                      <th className="text-left py-2 text-sm font-medium text-gray-500">Position</th>
                      <th className="text-left py-2 text-sm font-medium text-gray-500">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-gray-100">
                      <td className="py-3 text-sm text-gray-600">{candidate.date}</td>
                      <td className="py-3 text-sm text-gray-600">{candidate.position}</td>
                      <td className="py-3">
                        <span className={getStatusBadge(candidate.status)}>
                          {candidate.status}
                        </span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* CV Preview */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">CV Preview</h3>
            <div className="flex items-center space-x-4 mb-4">
              <div className="flex-1 bg-gray-100 rounded-lg p-8 text-center">
                <div className="space-y-4">
                  <div className="bg-white border-2 border-dashed border-gray-300 rounded-lg p-6">
                    <div className="text-sm text-gray-500 mb-2">CV Preview</div>
                    <div className="font-semibold">{candidate.name}</div>
                    <div className="text-sm text-gray-600">{candidate.position}</div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-gray-200 h-16 rounded"></div>
                    <div className="bg-gray-200 h-16 rounded"></div>
                    <div className="bg-gray-200 h-16 rounded"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Application Management */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Application Management</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Application Status
                </label>
                <select
                  value={applicationStatus}
                  onChange={(e) => handleStatusChange(e.target.value)}
                  className="input-field"
                >
                  <option value="Under Review">Under Review</option>
                  <option value="Interview Scheduled">Interview Scheduled</option>
                  <option value="Rejected">Rejected</option>
                  <option value="Hired">Hired</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Interview Scheduling
                </label>
                <input
                  type="text"
                  value={interviewDateTime}
                  onChange={(e) => setInterviewDateTime(e.target.value)}
                  placeholder="Schedule Interview (Date/Time)"
                  className="input-field"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notes & Interactions
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={4}
                  className="input-field resize-none"
                  placeholder="Add notes about the candidate..."
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Actions */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Actions</h3>
            <div className="space-y-3">
              <button
                onClick={handleSaveNote}
                className="w-full btn-secondary flex items-center justify-center space-x-2"
              >
                <Save className="h-4 w-4" />
                <span>Save note</span>
              </button>
              <button className="w-full btn-primary flex items-center justify-center space-x-2">
                <Download className="h-4 w-4" />
                <span>Download CV</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
