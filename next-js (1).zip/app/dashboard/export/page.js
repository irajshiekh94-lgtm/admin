'use client'

import { useState } from 'react'
import { Download, FileText, Table } from 'lucide-react'

export default function ExportData() {
  const [selectedFormat, setSelectedFormat] = useState('csv')
  const [isExporting, setIsExporting] = useState(false)

  const handleExport = async () => {
    setIsExporting(true)
    
    // Mock export functionality
    setTimeout(() => {
      setIsExporting(false)
      alert(`Exporting data in ${selectedFormat.toUpperCase()} format...`)
    }, 2000)
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-2xl font-bold text-gray-900">Export Data</h1>
        <p className="mt-2 text-sm text-gray-600">
          Choose the format for exporting application data.
        </p>
      </div>

      {/* Export Form */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Select Export Format</h3>
            
            <div className="space-y-4">
              {/* CSV Option */}
              <label className="relative flex items-start p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
                <div className="flex items-center h-5">
                  <input
                    type="radio"
                    name="exportFormat"
                    value="csv"
                    checked={selectedFormat === 'csv'}
                    onChange={(e) => setSelectedFormat(e.target.value)}
                    className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                  />
                </div>
                <div className="ml-3 flex-1">
                  <div className="flex items-center">
                    <FileText className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="text-sm font-medium text-gray-900">CSV</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">
                    Comma-separated values format, compatible with Excel and other spreadsheet applications.
                  </p>
                </div>
              </label>

              {/* Excel Option */}
              <label className="relative flex items-start p-4 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50">
                <div className="flex items-center h-5">
                  <input
                    type="radio"
                    name="exportFormat"
                    value="excel"
                    checked={selectedFormat === 'excel'}
                    onChange={(e) => setSelectedFormat(e.target.value)}
                    className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                  />
                </div>
                <div className="ml-3 flex-1">
                  <div className="flex items-center">
                    <Table className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="text-sm font-medium text-gray-900">Excel</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">
                    Microsoft Excel format with advanced formatting and formula support.
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* Export Options */}
          <div className="border-t border-gray-200 pt-6">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Export Options</h4>
            <div className="space-y-3">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700">Include candidate personal information</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  defaultChecked
                  className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700">Include application history</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700">Include CV file paths</span>
              </label>
            </div>
          </div>

          {/* Date Range */}
          <div className="border-t border-gray-200 pt-6">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Date Range (Optional)</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-700 mb-1">From Date</label>
                <input
                  type="date"
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-700 mb-1">To Date</label>
                <input
                  type="date"
                  className="input-field"
                />
              </div>
            </div>
          </div>

          {/* Export Button */}
          <div className="border-t border-gray-200 pt-6">
            <button
              onClick={handleExport}
              disabled={isExporting}
              className={`w-full flex items-center justify-center px-4 py-3 border border-transparent text-sm font-medium rounded-lg text-white ${
                isExporting
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
              } transition-colors`}
            >
              {isExporting ? (
                <>
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Exporting...
                </>
              ) : (
                <>
                  <Download className="h-5 w-5 mr-2" />
                  Export Data
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Export History */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Exports</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between py-2 border-b border-gray-100">
            <div>
              <p className="text-sm font-medium text-gray-900">Application Data - CSV</p>
              <p className="text-xs text-gray-500">Exported on July 20, 2024</p>
            </div>
            <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
              Download Again
            </button>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-gray-100">
            <div>
              <p className="text-sm font-medium text-gray-900">Candidate Report - Excel</p>
              <p className="text-xs text-gray-500">Exported on July 15, 2024</p>
            </div>
            <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
              Download Again
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
