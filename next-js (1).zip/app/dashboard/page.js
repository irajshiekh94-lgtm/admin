'use client'

import Link from 'next/link'
import { Search, ChevronLeft, ChevronRight } from 'lucide-react'
import { useApplicationContext } from '../context/ApplicationContext'

const chartData = [
  { week: 'Week 1', value: 20 },
  { week: 'Week 2', value: 45 },
  { week: 'Week 3', value: 35 },
  { week: 'Week 4', value: 60 },
]

export default function Dashboard() {
  const { candidates } = useApplicationContext()
  const getStatusBadge = (status) => {
    const baseClasses = 'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium'
    
    switch (status) {
      case 'applied':
        return `${baseClasses} bg-gray-100 text-gray-800`
      case 'interviewing':
        return `${baseClasses} bg-blue-100 text-blue-800`
      case 'rejected':
        return `${baseClasses} bg-red-100 text-red-800`
      default:
        return `${baseClasses} bg-gray-100 text-gray-800`
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="text-sm font-medium text-gray-500 mb-1">Total Applications</div>
          <div className="text-3xl font-bold text-gray-900">1,234</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="text-sm font-medium text-gray-500 mb-1">Positions Applied For</div>
          <div className="text-3xl font-bold text-gray-900">567</div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search candidates by name"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Candidates Table */}
      <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="table-header">Candidate Name</th>
                <th className="table-header">Position</th>
                <th className="table-header">Application Date</th>
                <th className="table-header">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {candidates.slice(0, 10).map((candidate) => (
                <tr key={candidate.id} className="hover:bg-gray-50">
                  <td className="table-cell font-medium">{candidate.name}</td>
                  <td className="table-cell text-gray-500">{candidate.position}</td>
                  <td className="table-cell text-gray-500">{candidate.date}</td>
                  <td className="table-cell">
                    <div className="flex space-x-2">
                      <Link
                        href={`/dashboard/candidate/${candidate.id}`}
                        className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        Preview CV
                      </Link>
                      <span className="text-gray-300">|</span>
                      <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        Download CV
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
          <div className="flex-1 flex justify-between sm:hidden">
            <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
              Previous
            </button>
            <button className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
              Next
            </button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                <button className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                  <ChevronLeft className="h-5 w-5" />
                </button>
                {[1, 2, 3, 4, 5].map((page) => (
                  <button
                    key={page}
                    className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                      page === 1
                        ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                        : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                    }`}
                  >
                    {page}
                  </button>
                ))}
                <button className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                  <ChevronRight className="h-5 w-5" />
                </button>
              </nav>
            </div>
          </div>
        </div>
      </div>

      {/* Application Trends */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Application Trends</h3>
        
        <div className="mb-4">
          <div className="text-sm text-gray-500 mb-1">Applications Over Time</div>
          <div className="text-2xl font-bold text-green-600">+15%</div>
          <div className="text-sm text-gray-500">Last 30 Days +15%</div>
        </div>

        {/* Simple chart representation */}
        <div className="mt-6">
          <div className="flex items-end justify-between h-32 space-x-2">
            {chartData.map((item, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div 
                  className="w-full bg-blue-200 rounded-t"
                  style={{ height: `${(item.value / 60) * 100}%` }}
                />
                <div className="text-xs text-gray-500 mt-2">{item.week}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
