'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Search, Download, Eye } from 'lucide-react'
import { useApplicationContext } from '../context/ApplicationContext'

export default function CVManagement() {
  const { candidates } = useApplicationContext()
  const [searchTerm, setSearchTerm] = useState('')
  const [filteredCVs, setFilteredCVs] = useState(candidates)

  const handleSearch = (e) => {
    const term = e.target.value.toLowerCase()
    setSearchTerm(term)
    
    if (term === '') {
      setFilteredCVs(candidates)
    } else {
      const filtered = candidates.filter(candidate =>
        candidate.name.toLowerCase().includes(term) ||
        candidate.position.toLowerCase().includes(term)
      )
      setFilteredCVs(filtered)
    }
  }

  const handleDownload = (candidateId, candidateName) => {
    // Mock download functionality
    alert(`Downloading CV for ${candidateName}`)
  }

  const handleView = (candidateId, candidateName) => {
    // Mock view functionality
    alert(`Viewing CV for ${candidateName}`)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Candidate CVs</h1>
        <p className="mt-1 text-sm text-gray-600">
          Browse and download CVs submitted by candidates.
        </p>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={handleSearch}
            placeholder="Search CV by name"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      {/* CVs Table */}
      <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="table-header">Candidate Name</th>
                <th className="table-header">Job Applied For</th>
                <th className="table-header">Submission Date</th>
                <th className="table-header">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredCVs.length > 0 ? (
                filteredCVs.map((cv) => (
                  <tr key={cv.id} className="hover:bg-gray-50">
                    <td className="table-cell font-medium">{cv.name}</td>
                    <td className="table-cell text-gray-500">{cv.position}</td>
                    <td className="table-cell text-gray-500">{cv.date}</td>
                    <td className="table-cell">
                      <div className="flex space-x-2">
                        <Link
                          href={`/dashboard/candidate/${cv.id}`}
                          className="inline-flex items-center text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Link>
                        <span className="text-gray-300">|</span>
                        <button
                          onClick={() => handleDownload(cv.id, cv.name)}
                          className="inline-flex items-center text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" className="px-6 py-12 text-center">
                    <div className="text-center">
                      <Search className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-sm font-medium text-gray-900">No CVs found</h3>
                      <p className="mt-1 text-sm text-gray-500">
                        Try adjusting your search criteria.
                      </p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        {filteredCVs.length > 0 && (
          <div className="bg-gray-50 px-6 py-3 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-700">
                Showing <span className="font-medium">{filteredCVs.length}</span> CVs
              </div>
              <div className="flex space-x-2">
                <button className="btn-secondary text-sm">
                  <Download className="h-4 w-4 mr-1" />
                  Download All
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
